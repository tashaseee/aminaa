import React from "react";
import Header from "./components/Header/Header";
import Hero from "./components/Hero/Hero";
import Categories from "./components/Categories/Categories";
import Footer from "./components/Footer/Footer";
import SectionBlock from "./components/cube1/SectionBlock";
import "./App.css";
import IceCreamCarousel from "./components/IceCreamCarousel/IceCreamCarousel";
import IceCreamCatalog from './components/IceCreamCatalog/IceCreamCatalog';
import TeamSection from "./components/TeamSection/TeamSection";
import FeedbackSection from "./components/FeedbackSection/FeedbackSection";
import { CartProvider } from "./components/CartContext/CartContext";
import CartDropdown from "./components/CartDropDown/CartDropDown";
import Checkout from "./components/CheckoutForm/Checkout"; // Исправил имя импортируемого компонента
import OrderSuccessNotification from "./components/OrderSuccessNotification/OrderSuccessNotification";

function App() {
  return (
    <CartProvider>
      <div className="app" style={{ maxWidth: '100%', margin: '0 auto', width: '100%', overflowX: 'hidden' }}>
        <Header />
        <Hero />
        <SectionBlock />
        <Categories />
        <IceCreamCatalog />
        <IceCreamCarousel />
        <TeamSection/>
        <FeedbackSection/>
        <Footer />
        
        {/* Cart components */}
        <CartDropdown />
        <Checkout />
        <OrderSuccessNotification />
      </div>
    </CartProvider>
  );
}

export default App;