import React, { useState, useEffect } from 'react';
import { useCart } from '../CartContext/CartContext';
import './Header.css';

const Header = () => {
  const [hoveredItem, setHoveredItem] = useState(null);
  const [isScrolled, setIsScrolled] = useState(false);
  const { setIsCartOpen, getTotalItems } = useCart();

  useEffect(() => {
    const handleScroll = () => {
      const scrolled = window.scrollY > 10;
      setIsScrolled(scrolled);
      
      // Добавляем класс к body для управления отступом при прокрутке
      if (scrolled) {
        document.body.classList.add('scrolled');
      } else {
        document.body.classList.remove('scrolled');
      }
    };
    
    // Запускаем обработчик при монтировании компонента
    handleScroll();
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleCartClick = () => {
    setIsCartOpen(true);
  };

  return (
    <header className={`header ${isScrolled ? 'scrolled' : ''}`}>
      <div className="header__container">
        <div className="header__logo">NOTO</div>

        <nav className="header__nav">
          {['Главная', 'Отзывы', 'Категория', 'Топ вкусов', 'Команда'].map((item) => (
            <a
              href={`#${item.toLowerCase()}`}
              className={`header__link ${hoveredItem === item ? 'hovered' : ''}`}
              onMouseEnter={() => setHoveredItem(item)}
              onMouseLeave={() => setHoveredItem(null)}
              key={item}
            >
              {item}
              <span className="link__underline"></span>
            </a>
          ))}
        </nav>

        <button className="header__button" onClick={handleCartClick}>
          <span className="button__text">В КОРЗИНУ {getTotalItems() > 0 && `(${getTotalItems()})`}</span>
          <span className="button__hover-effect"></span>
          {getTotalItems() > 0 && (
            <span className="cart-count">{getTotalItems()}</span>
          )}
        </button>
      </div>
    </header>
  );
};

export default Header;